<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset2" tilewidth="64" tileheight="64" tilecount="25" columns="5">
 <image source="tilemap2.png" width="320" height="320"/>
</tileset>

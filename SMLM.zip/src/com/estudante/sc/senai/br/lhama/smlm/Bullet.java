//package com.estudante.sc.senai.br.lhama.smlm;
//
//import br.senai.sc.engine.Fps;
//
//import java.awt.*;
//
//public class Bullet extends Sprite {
//	public Bullet(TileLayer map, Fps fps, String path, double maxSpeed, double x, double y, double xv, double yv) {
//
//	}
//}

package com.estudante.sc.senai.br.lhama.smlm;

public enum ZMode {
	CENTER, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
}

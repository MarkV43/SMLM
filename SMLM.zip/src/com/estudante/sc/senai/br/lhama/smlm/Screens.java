package com.estudante.sc.senai.br.lhama.smlm;

public enum Screens {
	MAIN, PAUSE, GAME, CONTROLS, OPTIONS
}

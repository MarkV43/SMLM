package com.estudante.sc.senai.br.lhama.smlm;

import java.awt.*;

public interface Screen {
	void draw(Graphics2D g2d);
}

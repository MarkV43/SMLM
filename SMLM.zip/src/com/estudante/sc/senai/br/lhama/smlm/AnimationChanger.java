package com.estudante.sc.senai.br.lhama.smlm;

/**
 * Created by Marcelo Vogt on 19/11/2017.
 */
public interface AnimationChanger {
	String change(Sprite spr);
}
